#include<stdio.h>
void sleep(int s){
	printf("i am not sleeping!!!\n");
}
